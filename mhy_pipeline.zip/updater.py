import requests
import platform
import subprocess
import datetime
import os

# Server URL and API endpoint to check the latest version
SERVER_URL = "https://your-server.com"
VERSION_ENDPOINT = "/api/get_latest_version"

def check_latest_version():
    try:
        response = requests.get(f"{SERVER_URL}{VERSION_ENDPOINT}")
        if response.status_code == 200:
            latest_version = response.json()["version"]
            return latest_version
        else:
            return None
    except requests.exceptions.RequestException:
        return None

def download_and_install_installer():
    # Replace this URL with the URL of the latest installer on the server
    installer_url = f"{SERVER_URL}/path/to/latest_installer.exe"
    # You can use different download techniques like urllib or wget
    # Here, I'm using the 'subprocess' module to execute the installer after download.
    if platform.system() == "Windows":
        subprocess.run(["powershell", "Invoke-WebRequest", installer_url, "-OutFile", "latest_installer.exe"])
        subprocess.run(["latest_installer.exe"])  # Execute the installer
    # Add support for other operating systems if needed.

def save_last_check_date():
    # Save the current date as the last check date
    with open("last_check_date.txt", "w") as file:
        file.write(str(datetime.datetime.today().date()))

def get_last_check_date():
    # Read the last check date from the file
    try:
        with open("last_check_date.txt", "r") as file:
            return file.read()
    except FileNotFoundError:
        # Return a default date if the file doesn't exist yet
        return "1970-01-01"

def main():
    today = datetime.datetime.today().strftime("%A")
    if today == "Sunday":
        last_check_date = get_last_check_date()
        if last_check_date != str(datetime.datetime.today().date()):
            installed_version = "1.0"  # Replace this with the version of your installed app
            latest_version = check_latest_version()
            if latest_version and latest_version != installed_version:
                download_and_install_installer()
            save_last_check_date()

if __name__ == "__main__":
    main()
