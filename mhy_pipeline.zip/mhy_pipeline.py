import sys
import win32gui
import win32con
import win32api
import win32gui_struct
import ctypes
import json


class Runner:
    def __init__(self, icon, tooltip, menu_options):
        self.icon = icon
        self.tooltip = tooltip
        self.menu_options = menu_options
        self._message_map = {
            win32con.WM_DESTROY: self.on_destroy,
            win32con.WM_COMMAND: self.on_command,
            win32con.WM_USER+20: self.on_taskbar_notify
        }

        # Register the window class
        wc = win32gui.WNDCLASS()
        hinst = wc.hInstance = win32api.GetModuleHandle(None)
        wc.lpszClassName = 'PythonTaskbar'
        wc.lpfnWndProc = self._message_handler
        class_atom = win32gui.RegisterClass(wc)

        # Create the window
        style = win32con.WS_OVERLAPPED | win32con.WS_SYSMENU
        self.hwnd = win32gui.CreateWindow(class_atom, 'Taskbar', style,
                                          0, 0, win32con.CW_USEDEFAULT,
                                          win32con.CW_USEDEFAULT, 0, 0,
                                          hinst, None)
        win32gui.UpdateWindow(self.hwnd)
        self.notify_id = None
        self.refresh_icon()

        #################################################################################
        # Query info from config.json
        with open("config.json", "r") as file:
            self.config = json.load(file)


    def refresh_icon(self):
        # Load the icon and add to the system tray
        hicon = win32gui.LoadImage(0, self.icon, win32con.IMAGE_ICON,
                                   0, 0, win32con.LR_LOADFROMFILE)
        if self.notify_id:
            message = win32gui.NIM_MODIFY
        else:
            message = win32gui.NIM_ADD
        self.notify_id = (self.hwnd, 0, win32gui.NIF_ICON | win32gui.NIF_MESSAGE | win32gui.NIF_TIP, win32con.WM_USER+20, hicon, self.tooltip)
        win32gui.Shell_NotifyIcon(message, self.notify_id)

    def on_destroy(self, hwnd, msg, wparam, lparam):
        nid = (self.hwnd, 0)
        win32gui.Shell_NotifyIcon(win32gui.NIM_DELETE, nid)
        win32gui.PostQuitMessage(0)

    def on_command(self, hwnd, msg, wparam, lparam):
        id = win32gui.LOWORD(wparam)
        for option in self.menu_options:
            if id == option[0]:
                option[1]()

    def on_taskbar_notify(self, hwnd, msg, wparam, lparam):
        if lparam == win32con.WM_LBUTTONUP:
            pass  # Single-click event handling
        elif lparam == win32con.WM_LBUTTONDBLCLK:
            pass  # Double-click event handling
        elif lparam == win32con.WM_RBUTTONUP:
            self.show_menu()
        return True

    def show_menu(self):
        menu = win32gui.CreatePopupMenu()
        for option in self.menu_options:
            win32gui.AppendMenu(menu, win32con.MF_STRING, option[0], option[2])
        pos = win32gui.GetCursorPos()
        win32gui.SetForegroundWindow(self.hwnd)
        win32gui.TrackPopupMenu(menu, win32con.TPM_LEFTALIGN, pos[0], pos[1], 0, self.hwnd, None)
        win32gui.PostMessage(self.hwnd, win32con.WM_NULL, 0, 0)

    def _message_handler(self, hwnd, msg, wparam, lparam):
        if msg == win32con.WM_CREATE:
            self.hinst = win32gui_struct.HMODULE(ctypes.windll.kernel32.GetModuleHandle(None))
            return 0
        if msg == win32con.WM_DESTROY:
            self.on_destroy(hwnd, msg, wparam, lparam)
        elif msg == win32con.WM_COMMAND:
            self.on_command(hwnd, msg, wparam, lparam)
        elif msg == win32con.WM_USER+20:
            self.on_taskbar_notify(hwnd, msg, wparam, lparam)
        else:
            return win32gui.DefWindowProc(hwnd, msg, wparam, lparam)
        return 0

# Callback functions for the menu options
def open_file():
    win32api.ShellExecute(0, "open", "notepad.exe", None, None, 1)

def close_application():
    sys.exit()

if __name__ == "__main__":
    icon_path = 'mi.ico'
    tooltip_text = 'MHY Pipeline'
    menu_options = [
        (1, lambda: print("Open UI"), "Open UI"),
        (2, lambda: print("Update"), "Update"),
        (3, lambda: sys.exit(), "Exit")
    ]

    # Create the Runner instance and assign it to a global variable
    sys_runner = Runner(icon_path, tooltip_text, menu_options)

    # Run the application event loop
    win32gui.PumpMessages()
