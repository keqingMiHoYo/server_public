import requests
import platform
import subprocess
import datetime
import os
import zipfile
import shutil
import tempfile
import urllib.request
import json


class Updater:
    def __init__(self):

        # Read Config JSON
        try:
            with open("config.json", "r") as file:
                self.config = json.load(file)
        except FileNotFoundError:
            print(f"File not found: config.json")
        except json.JSONDecodeError:
            print(f"Invalid JSON format in file: config.json")
        except Exception as e:
            print(f"Error occurred while reading config.json: {str(e)}")

        self.current_version = self.config['version_number']
        self.latest_version = ""

    def update(self):
        self.latest_version = self.get_latest_version()
        if not self.latest_version or int(self.latest_version) <= int(self.current_version):
            print("No need to update")
            return
        print("Need to update")
        self.download_and_run_installer()

    def download_and_run_installer(self):
        temp_dir = tempfile.gettempdir()

        # Download the zip file
        installer_url = f"{self.config['installer']}{self.latest_version}{self.config['installer_ext']}"
        print("installer url: " + installer_url)
        response = requests.get(installer_url)
        
        # Check if the download was successful
        if response.status_code == 200:
            # Save the downloaded zip file
            zip_path = os.path.join(temp_dir, self.config['download_file']+self.config['installer_ext'])
            with open(zip_path, "wb") as file:
                file.write(response.content)
            print("download file")
            
            # Unzip the file
            extracted_folder = os.path.join(temp_dir, self.config['base_folder'])
            with zipfile.ZipFile(zip_path, "r") as zip_ref:
                zip_ref.extractall(extracted_folder)
            print("unzip file")
            
            # Run installer.py from the extracted folder
            installer_path = os.path.join(extracted_folder, "installer.py")
            print("installer path: " + installer_path)
            subprocess.run(["python", installer_path])

        else:
            print("Failed to download the installer.")

    def get_latest_version(self):
        try:
            response = requests.get(f"{self.config['config']}")
            if response.status_code == 200:
                latest_version = response.json()["version_number"]
                print("Version number from server: " + latest_version)
                return latest_version
            else:
                print("Cannot query the latest version from the server")
                return None
        except requests.exceptions.RequestException:
            print("Cannot query the latest version from the server")
            return None


if __name__ == "__main__":
    updater = Updater()
    updater.update()
        

