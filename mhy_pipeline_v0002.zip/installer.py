import os
import shutil
import subprocess
import psutil
import datetime
import json


BASE_DIR = os.path.expanduser("~\Documents")


class Installer:
    def __init__(self):

        # Read Config JSON
        try:
            with open("config.json", "r") as file:
                self.config = json.load(file)
        except FileNotFoundError:
            print(f"File not found: config.json")
        except json.JSONDecodeError:
            print(f"Invalid JSON format in file: config.json")
        except Exception as e:
            print(f"Error occurred while reading config.json: {str(e)}")

    def install(self):
        # Kill existing processes
        print("kill processes")
        self.kill_process_by_name(self.config['runner_name'])
        self.kill_process_by_name(self.config['updater_name'])

        # Update the last update date in config.json
        self.config["last_update"] = datetime.date.today().strftime("%Y-%m-%d")
        with open("config.json", "w") as file:
            json.dump(self.config, file)

        # Replace old files with new ones
        print("replace files")
        dest_dir = f"{BASE_DIR}/{self.config['base_folder']}"
        print("dest_dir: " + dest_dir)
        if os.path.exists(dest_dir):
            try:
                shutil.rmtree(dest_dir)
                os.rmdir(dest_dir)
            except OSError as e:
                print(f"Error while removing folder: {e}")
                return
        src_dir = os.path.dirname(os.path.abspath(__file__))
        shutil.copytree(src_dir, dest_dir)

        # Run mhy_pipeline.exe in Documents folder
        runner_path = os.path.join(dest_dir, "mhy_pipeline.exe")
        subprocess.run(runner_path)

        print("Installer exits")
    
    def kill_process_by_name(self, name):
        for process in psutil.process_iter(['pid', 'name']):
            if process.info['name'] == name:
                process.kill()


if __name__ == "__main__":
    installer = Installer()
    installer.install()

