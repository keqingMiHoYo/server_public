import requests
import platform
import subprocess
import datetime
import os
import zipfile
import shutil
import tempfile
import urllib.request
import json


# BASE_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = r"C:\Users\keqing\Documents\MHY\framework"
TEMP_DIR = tempfile.gettempdir()


class Updater:
    def __init__(self):
        # Read Config JSON
        self.config = None
        try:
            with open(BASE_DIR + "\config.json", "r") as file:
                self.config = json.load(file)
        except FileNotFoundError:
            print(f"File not found: config.json")
            print("config path: " + BASE_DIR + "//config.json")
        except json.JSONDecodeError:
            print(f"Invalid JSON format in file: config.json")
        except Exception as e:
            print(f"Error occurred while reading config.json: {str(e)}")

        self.current_version = self.config['version_number']
        self.latest_version = ""

    def update(self):
        self.latest_version = self.get_latest_version()
        if not self.latest_version or int(self.latest_version) <= int(self.current_version):
            print("No need to update")
            return
        print("Need to update")
        self.download_and_run_installer()

    def download_and_run_installer(self):
        # Download the zip file
        installer_url = f"{self.config['installer']}{self.latest_version}{self.config['installer_ext']}"
        print("installer url: " + installer_url)
        response = requests.get(installer_url)
        
        # Check if the download was successful
        if response.status_code == 200:
            # Remove the old zip file
            zip_path = os.path.join(TEMP_DIR, self.config['download_file']+self.config['installer_ext'])
            if os.path.exists(zip_path):
                os.remove(zip_path)
                print(f"{zip_path} has been deleted.")
            else:
                print(f"{zip_path} does not exist.")
            
            # Save the downloaded zip file
            with open(zip_path, "wb") as file:
                file.write(response.content)
            print("download file")
            
            # Remove the old unzip folder
            extracted_folder = os.path.join(TEMP_DIR, self.config['base_folder'])
            if os.path.exists(extracted_folder):
                try:
                    shutil.rmtree(extracted_folder)
                except OSError as e:
                    print(f"Error while removing folder: {e}")
                    return

            # Unzip the file
            with zipfile.ZipFile(zip_path, "r") as zip_ref:
                zip_ref.extractall(extracted_folder)
            print("unzip file")
            
            # Run installer.py from the extracted folder
            # installer_path = os.path.join(extracted_folder, "installer.py")
            installer_path = extracted_folder + "/framework/installer.py"
            print("installer path: " + installer_path)
            subprocess.run(["python", installer_path])

        else:
            print("Failed to download the installer.")

    def get_latest_version(self):
        try:
            response = requests.get(f"{self.config['config']}")
            if response.status_code == 200:
                latest_version = response.json()["version_number"]
                print("Version number from server: " + latest_version)
                return latest_version
            else:
                print("Cannot query the latest version from the server")
                return None
        except requests.exceptions.RequestException:
            print("Cannot query the latest version from the server")
            return None


if __name__ == "__main__":
    updater = Updater()
    updater.update()
        

